# Add PDF drug subcategories to shop browsing

## Build
- Add the drug classification names and example medicines from the supplied PDF to the Pharmaceutical browsing experience.
- Let shoppers choose a subcategory and see its examples without implying those examples are currently stocked.
- Preserve the existing shop search, top-level category selection, sorting, cart, and mobile layout.

## Technical details
- Keep the enhancement in the existing shop route and semantic CSS tokens; avoid changing the product inventory model because the PDF does not confirm current stock.
- Ensure the shop page has the required page-specific social metadata.