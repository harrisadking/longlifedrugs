<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Buyers get genuine healthcare supplies they need, delivered on time.

## Metric

Orders placed each week
