import { createFileRoute, Link } from "@tanstack/react-router";
import { AlertTriangle, Package, PackageX, ReceiptText, Wallet } from "lucide-react";

import { naira, useAllProducts, useOrders } from "@/lib/store";

export const Route = createFileRoute("/admin/")({
  component: Dashboard,
});

function Dashboard() {
  const products = useAllProducts();
  const orders = useOrders();

  const active = products.filter((product) => product.active).length;
  const outOfStock = products.filter((product) => product.stock <= 0);
  const lowStock = products.filter((product) => product.stock > 0 && product.stock <= 10);
  const newOrders = orders.filter((order) => order.status === "New").length;
  const revenue = orders.filter((order) => order.status === "Delivered").reduce((sum, order) => sum + order.total, 0);

  const stats = [
    { Icon: Package, label: "Products live", value: `${active} / ${products.length}`, to: "/admin/products" as const },
    { Icon: PackageX, label: "Out of stock", value: String(outOfStock.length), to: "/admin/products" as const },
    { Icon: ReceiptText, label: "New orders", value: String(newOrders), to: "/admin/orders" as const },
    { Icon: Wallet, label: "Delivered revenue", value: naira(revenue), to: "/admin/orders" as const },
  ];

  return (
    <>
      <div className="admin-heading"><h1>Dashboard</h1><p>A quick look at your store.</p></div>

      <div className="stat-grid">
        {stats.map(({ Icon, label, value, to }) => (
          <Link key={label} to={to} className="stat-card">
            <span className="info-icon"><Icon /></span>
            <div><span>{label}</span><strong>{value}</strong></div>
          </Link>
        ))}
      </div>

      <div className="admin-two-col">
        <section className="admin-card">
          <h2><AlertTriangle size={17} /> Stock needing attention</h2>
          {outOfStock.length + lowStock.length === 0 ? (
            <p className="muted">All products are well stocked.</p>
          ) : (
            <ul className="plain-list">
              {[...outOfStock, ...lowStock].map((product) => (
                <li key={product.id}>
                  <span>{product.name}</span>
                  <b className={product.stock <= 0 ? "pill pill-red" : "pill pill-amber"}>{product.stock <= 0 ? "Out of stock" : `${product.stock} left`}</b>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="admin-card">
          <h2><ReceiptText size={17} /> Latest orders</h2>
          {orders.length === 0 ? (
            <p className="muted">No orders logged yet. Add orders you receive on WhatsApp from the Orders page.</p>
          ) : (
            <ul className="plain-list">
              {orders.slice(0, 5).map((order) => (
                <li key={order.id}>
                  <span>{order.customer || "Customer"} · {naira(order.total)}</span>
                  <b className="pill">{order.status}</b>
                </li>
              ))}
            </ul>
          )}
          <Link to="/admin/orders" className="admin-link-more">View all orders</Link>
        </section>
      </div>

      <section className="admin-card admin-note">
        <h2>Good to know</h2>
        <p>Changes you make here are saved in this browser only, so shoppers on other devices will not see them yet. Use <Link to="/admin/settings">Settings → Backup</Link> to export your data. Connecting a hosted database is the step that makes edits live for everyone.</p>
      </section>
    </>
  );
}