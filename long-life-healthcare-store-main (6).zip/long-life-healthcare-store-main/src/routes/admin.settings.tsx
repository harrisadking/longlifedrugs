import { useState, type ChangeEvent, type FormEvent } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Download, Upload } from "lucide-react";

import { Button } from "@/components/ui/button";
import { exportBackup, importBackup, notify, saveSettings, useSettings, type Settings } from "@/lib/store";

export const Route = createFileRoute("/admin/settings")({
  component: AdminSettings,
});

function AdminSettings() {
  const current = useSettings();
  const [form, setForm] = useState<Settings>(current);
  const [error, setError] = useState("");
  const [newPass, setNewPass] = useState("");
  const [passError, setPassError] = useState("");

  const update = (key: keyof Settings) => (event: ChangeEvent<HTMLInputElement>) => setForm({ ...form, [key]: event.target.value });

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    const digits = form.whatsapp.replace(/\D/g, "");
    if (digits.length < 10) return setError("Enter the WhatsApp number with its country code, e.g. 2348030460998.");
    if (!form.storeName.trim()) return setError("Store name cannot be empty.");
    if (!(await saveSettings({ ...form, whatsapp: digits, storeName: form.storeName.trim() }))) return setError("Could not save settings. Check your connection and try again.");
    setError("");
    notify("Settings saved.");
  };

  const changePasscode = async (event: FormEvent) => {
    event.preventDefault();
    if (newPass.trim().length < 6) return setPassError("Use at least 6 characters.");
    if (!(await saveSettings({ ...current, adminPasscode: newPass.trim() }))) return setPassError("Could not save. Check your connection and try again.");
    setNewPass("");
    setPassError("");
    notify("Passcode updated.");
  };

  const download = () => {
    const blob = new Blob([exportBackup()], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `long-life-backup-${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const restore = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (!window.confirm("Restore this backup? It will replace your current products, orders and settings.")) return;
    const problem = importBackup(await file.text());
    notify(problem ?? "Backup restored.");
  };

  return (
    <>
      <div className="admin-heading"><h1>Settings</h1><p>Contact details and WhatsApp checkout.</p></div>

      <form className="admin-card settings-form" onSubmit={submit}>
        <h2>Store details</h2>
        <label className="field">Store name<input value={form.storeName} onChange={update("storeName")} /></label>
        <label className="field">WhatsApp number for orders
          <input value={form.whatsapp} onChange={update("whatsapp")} inputMode="numeric" placeholder="2348030460998" />
          <small>Digits only, with country code and no “+”. Every order and chat button uses this number.</small>
        </label>
        <div className="field-row">
          <label className="field">Phone (shown on site)<input value={form.phone} onChange={update("phone")} /></label>
          <label className="field">Email<input value={form.email} onChange={update("email")} inputMode="email" /></label>
        </div>
        <label className="field">Address<input value={form.address} onChange={update("address")} /></label>
        <label className="field">Opening hours<input value={form.hours} onChange={update("hours")} /></label>
        {error && <p className="form-error" role="alert">{error}</p>}
        <div className="form-actions"><Button type="submit" className="shop-button">Save settings</Button></div>
      </form>

      <form className="admin-card settings-form" onSubmit={changePasscode}>
        <h2>Admin passcode</h2>
        <p className="muted">The passcode only keeps casual visitors out. It is checked in the browser, so it is not real security. Do not store anything sensitive here.</p>
        <label className="field">New passcode<input type="password" value={newPass} onChange={(event) => setNewPass(event.target.value)} autoComplete="new-password" /></label>
        {passError && <p className="form-error" role="alert">{passError}</p>}
        <div className="form-actions"><Button type="submit" className="shop-button">Update passcode</Button></div>
      </form>

      <section className="admin-card settings-form">
        <h2>Backup</h2>
        <p className="muted">Your products, orders and settings live in this browser. Download a backup regularly, and use it to move your data to another browser or computer.</p>
        <div className="form-actions start">
          <Button type="button" className="shop-button" onClick={download}><Download size={16} /> Download backup</Button>
          <label className="admin-ghost file-button"><Upload size={15} /> Restore backup<input type="file" accept="application/json,.json" onChange={restore} hidden /></label>
        </div>
      </section>
    </>
  );
}