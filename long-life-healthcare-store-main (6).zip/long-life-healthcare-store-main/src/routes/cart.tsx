import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, ShoppingCart } from "lucide-react";

import { CartLines, CheckoutForm, SiteLayout } from "@/components/site-layout";
import { Button } from "@/components/ui/button";
import { cartCount, clearCart, useCart } from "@/lib/store";

export const Route = createFileRoute("/cart")({
  head: () => ({ meta: [{ title: "Checkout | Long Life Healthcare Supplies" }] }),
  component: CartPage,
});

function CartPage() {
  const cart = useCart();
  const count = cartCount(cart);

  return (
    <SiteLayout>
      <section className="ck-head">
        <nav className="breadcrumb" aria-label="Breadcrumb"><Link to="/">Home</Link><span>/</span><span>Checkout</span></nav>
        <h1>Checkout</h1>
        <p>{count ? `${count} item${count === 1 ? "" : "s"} ready to order` : "Nothing here yet"}</p>
      </section>

      {cart.length === 0 ? (
        <section className="panel empty-panel">
          <ShoppingCart size={40} />
          <h2>Your cart is empty</h2>
          <p>Add a few products and send your order on WhatsApp.</p>
          <Button asChild className="shop-button"><Link to="/shop" search={{ q: undefined, category: undefined }}>Browse products <ArrowRight size={16} /></Link></Button>
        </section>
      ) : (
        <section className="ck-layout">
          <div className="ck-card ck-items">
            <div className="ck-card-head">
              <h2 className="ck-h">Your items</h2>
              <button type="button" className="ck-clear" onClick={clearCart}>Clear cart</button>
            </div>
            <CartLines lines={cart} />
            <Link to="/shop" search={{ q: undefined, category: undefined }} className="ck-continue"><ArrowLeft size={16} /> Continue shopping</Link>
          </div>
          <aside className="ck-side" aria-label="Order summary and delivery details">
            <CheckoutForm lines={cart} />
          </aside>
        </section>
      )}
    </SiteLayout>
  );
}