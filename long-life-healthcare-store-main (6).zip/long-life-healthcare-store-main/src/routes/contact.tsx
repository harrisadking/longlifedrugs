import { useState, type FormEvent } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Clock, Mail, MapPin, MessageCircle, Phone } from "lucide-react";

import { SiteLayout } from "@/components/site-layout";
import { notify, useSettings, whatsappUrl } from "@/lib/store";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact | Long Life Healthcare Supplies" },
      { name: "description", content: "Get in touch with Long Life by WhatsApp, phone or email." },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  const settings = useSettings();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [message, setMessage] = useState("");

  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!message.trim()) {
      notify("Please write a short message first.");
      return;
    }
    const text = [`Hello ${settings.storeName},`, "", message.trim(), "", name.trim() ? `Name: ${name.trim()}` : "", phone.trim() ? `Phone: ${phone.trim()}` : ""].filter((line, index, all) => line !== "" || all[index - 1] !== "").join("\n").trim();
    window.open(whatsappUrl(settings.whatsapp, text), "_blank", "noopener,noreferrer");
  };

  const cards = [
    { Icon: MessageCircle, title: "WhatsApp", value: "Chat with us", href: whatsappUrl(settings.whatsapp, `Hello ${settings.storeName}, I have a question.`), external: true },
    { Icon: Phone, title: "Phone", value: settings.phone, href: `tel:${settings.phone.replace(/[^+\d]/g, "")}` },
    { Icon: Mail, title: "Email", value: settings.email, href: `mailto:${settings.email}` },
    { Icon: MapPin, title: "Address", value: settings.address },
    { Icon: Clock, title: "Opening hours", value: settings.hours },
  ];

  return (
    <SiteLayout>
      <section className="page-hero">
        <nav className="breadcrumb" aria-label="Breadcrumb"><Link to="/">Home</Link><span>/</span><span>Contact</span></nav>
        <h1>Contact Us</h1>
        <p>Questions, quotes or bulk orders? We usually reply fastest on WhatsApp.</p>
      </section>

      <section className="contact-layout">
        <div className="contact-cards">
          {cards.map(({ Icon, title, value, href, external }) => {
            const body = (
              <>
                <span className="info-icon"><Icon /></span>
                <div><strong>{title}</strong><span>{value}</span></div>
              </>
            );
            return href ? (
              <a key={title} className="info-card contact-card" href={href} {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}>{body}</a>
            ) : (
              <div key={title} className="info-card contact-card">{body}</div>
            );
          })}
        </div>

        <form className="panel contact-form" onSubmit={submit}>
          <h2>Send us a message</h2>
          <p>Your message opens in WhatsApp so we can reply directly.</p>
          <label>Name<input value={name} onChange={(event) => setName(event.target.value)} autoComplete="name" placeholder="Your name" /></label>
          <label>Phone<input value={phone} onChange={(event) => setPhone(event.target.value)} autoComplete="tel" inputMode="tel" placeholder="Your phone number" /></label>
          <label>Message<textarea value={message} onChange={(event) => setMessage(event.target.value)} rows={5} placeholder="How can we help?" required /></label>
          <button type="submit" className="whatsapp-checkout"><MessageCircle size={18} /> Send on WhatsApp</button>
        </form>
      </section>
    </SiteLayout>
  );
}