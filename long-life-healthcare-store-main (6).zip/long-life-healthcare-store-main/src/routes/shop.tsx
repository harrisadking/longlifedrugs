import { useMemo, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Search, X } from "lucide-react";

import { ProductCard } from "@/components/product-card";
import { SiteLayout } from "@/components/site-layout";
import { DRUG_CLASSIFICATIONS, DRUG_CLASSIFICATION_NAMES } from "@/lib/drug-classifications";
import { CATEGORY_NAMES, useCatalogReady, useProducts } from "@/lib/store";

type ShopSearch = { q?: string | undefined; category?: string | undefined; subcategory?: string | undefined };

export const Route = createFileRoute("/shop")({
  validateSearch: (search: Record<string, unknown>): ShopSearch => {
    const q = search["q"];
    const category = search["category"];
    const subcategory = search["subcategory"];
    return {
      q: typeof q === "string" && q ? q : undefined,
      category: typeof category === "string" && category ? category : undefined,
      subcategory: typeof subcategory === "string" && DRUG_CLASSIFICATION_NAMES.includes(subcategory) ? subcategory : undefined,
    };
  },
  head: () => ({
    meta: [
      { title: "Shop | Long Life Healthcare Supplies" },
      { name: "description", content: "Browse pharmaceutical, medical & surgical, laboratory and dental supplies." },
      { property: "og:title", content: "Shop | Long Life Healthcare Supplies" },
      { property: "og:description", content: "Browse Long Life healthcare supplies by category and Pharmaceutical subcategory." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ShopPage,
});

type Sort = "featured" | "price-asc" | "price-desc" | "name";

function ShopPage() {
  const { q = "", category = "All", subcategory } = Route.useSearch();
  const selectedCategory = subcategory ? "Pharmaceutical" : category;
  const navigate = useNavigate({ from: "/shop" });
  const products = useProducts();
  const ready = useCatalogReady();
  const [sort, setSort] = useState<Sort>("featured");
  const selectedClassification = DRUG_CLASSIFICATIONS.find(({ name }) => name === subcategory);

  const visible = useMemo(() => {
    const term = q.trim().toLowerCase();
    const list = products.filter((product) => {
      const inCategory = selectedCategory === "All" || product.category === selectedCategory;
      const matches = !term || `${product.name} ${product.category} ${product.description}`.toLowerCase().includes(term);
      const classificationText = `${product.name} ${product.description}`.toLowerCase();
      const matchesClassification = !selectedClassification || selectedClassification.examples.some((example) => classificationText.includes(example.toLowerCase()));
      return inCategory && matches && matchesClassification;
    });
    const sorted = [...list];
    if (sort === "price-asc") sorted.sort((a, b) => a.price - b.price);
    if (sort === "price-desc") sorted.sort((a, b) => b.price - a.price);
    if (sort === "name") sorted.sort((a, b) => a.name.localeCompare(b.name));
    return sorted;
  }, [products, q, selectedCategory, selectedClassification, sort]);

  const setCategory = (next: string) => navigate({ search: { q: q || undefined, category: next === "All" ? undefined : next, subcategory: undefined } });
  const setSubcategory = (next?: string) => navigate({ search: { q: q || undefined, category: "Pharmaceutical", subcategory: next } });

  return (
    <SiteLayout>
      <section className="page-hero">
        <nav className="breadcrumb" aria-label="Breadcrumb"><Link to="/">Home</Link><span>/</span><span>Shop</span></nav>
        <h1>{selectedCategory === "All" ? "All Products" : selectedCategory}</h1>
        <p>Genuine healthcare supplies, ordered in minutes on WhatsApp.</p>
      </section>

      <section className="products-section shop-section">
        <div className="shop-toolbar">
          <label className="search-box shop-search">
            <Search size={17} />
            <input
              aria-label="Filter products"
              placeholder="Search products..."
              value={q}
              onChange={(event) => navigate({ search: { q: event.target.value || undefined, category: selectedCategory === "All" ? undefined : selectedCategory, subcategory }, replace: true })}
            />
            {q && <button type="button" aria-label="Clear search" onClick={() => navigate({ search: { q: undefined, category: selectedCategory === "All" ? undefined : selectedCategory, subcategory }, replace: true })}><X size={14} /></button>}
          </label>
          <label className="sort-select">
            <span>Sort by</span>
            <select value={sort} onChange={(event) => setSort(event.target.value as Sort)}>
              <option value="featured">Featured</option>
              <option value="price-asc">Price: low to high</option>
              <option value="price-desc">Price: high to low</option>
              <option value="name">Name A–Z</option>
            </select>
          </label>
        </div>

        <div className="filter-chips" role="tablist" aria-label="Filter products by category">
          {["All", ...CATEGORY_NAMES].map((name) => (
            <button key={name} type="button" role="tab" aria-selected={selectedCategory === name} className={selectedCategory === name ? "chip chip-active" : "chip"} onClick={() => setCategory(name)}>
              {name}
            </button>
          ))}
        </div>

        {selectedCategory === "Pharmaceutical" && (
          <section className="classification-browser" aria-label="Pharmaceutical subcategories">
            <h2>Browse Pharmaceutical subcategories</h2>
            <div className="filter-chips classification-chips" role="tablist" aria-label="Filter by Pharmaceutical subcategory">
              <button type="button" role="tab" aria-selected={!subcategory} className={!subcategory ? "chip chip-active" : "chip"} onClick={() => setSubcategory()}>All medicines</button>
              {DRUG_CLASSIFICATIONS.map(({ name }) => (
                <button key={name} type="button" role="tab" aria-selected={subcategory === name} className={subcategory === name ? "chip chip-active" : "chip"} onClick={() => setSubcategory(name)}>{name}</button>
              ))}
            </div>
            {selectedClassification && (
              <div className="classification-examples" aria-live="polite">
                <strong>{selectedClassification.name}</strong>
                <span>Example medicines—not a guarantee of current stock.</span>
                <ul>{selectedClassification.examples.map((example) => <li key={example}>{example}</li>)}</ul>
              </div>
            )}
          </section>
        )}

        <p className="result-count">{selectedClassification ? `${visible.length} matching store product${visible.length === 1 ? "" : "s"}` : `${visible.length} product${visible.length === 1 ? "" : "s"}`}</p>

        <div className="product-grid shop-grid">
          {visible.map((product) => <ProductCard key={product.id} product={product} />)}
          {!ready && <p className="no-results" role="status">Loading products...</p>}
          {ready && visible.length === 0 && <p className="no-results">{selectedClassification ? "No matching products are currently listed in the store." : "No products found. Try another search or category."}</p>}
        </div>
      </section>
    </SiteLayout>
  );
}