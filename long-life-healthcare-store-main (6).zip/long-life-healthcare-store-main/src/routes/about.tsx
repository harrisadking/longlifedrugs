import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, HeartHandshake, Headset, ShieldCheck, Tag, Truck } from "lucide-react";

import { SiteLayout } from "@/components/site-layout";
import { Button } from "@/components/ui/button";
import { useSettings } from "@/lib/store";
import careTeamPhoto from "@/assets/longlife-care-team.webp";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Us | Long Life Healthcare Supplies" },
      { name: "description", content: "Learn about Long Life and our commitment to genuine, reliable healthcare supplies." },
    ],
  }),
  component: AboutPage,
});

const values = [
  { title: "Genuine products", text: "We stock authentic, quality-assured pharmaceutical, medical, laboratory and dental supplies.", Icon: ShieldCheck },
  { title: "Reliable delivery", text: "Orders are confirmed with you directly and delivered in good condition.", Icon: Truck },
  { title: "Real support", text: "Talk to a person on WhatsApp for advice, availability and quotes.", Icon: Headset },
  { title: "Fair prices", text: "Competitive pricing so clinics, labs and families get better value for care.", Icon: Tag },
];

function AboutPage() {
  const settings = useSettings();
  return (
    <SiteLayout>
      <section className="page-hero">
        <nav className="breadcrumb" aria-label="Breadcrumb"><Link to="/">Home</Link><span>/</span><span>About Us</span></nav>
        <h1>About {settings.storeName}</h1>
        <p>Your trusted partner in healthcare supplies.</p>
      </section>

      <section className="about-story panel">
        <div className="about-photo"><img src={careTeamPhoto} alt="Healthcare professional reviewing patient information" width={1024} height={1024} loading="lazy" /></div>
        <div className="about-copy">
          <p className="eyebrow">OUR STORY</p>
          <h2>Reliable supply for a healthier tomorrow</h2>
          <p>{settings.storeName} supplies pharmaceuticals, medical and surgical products, laboratory consumables and dental equipment to clinics, hospitals, laboratories, pharmacies and households.</p>
          <p>We believe good care starts with products you can trust. That is why we focus on genuine stock, honest pricing and a simple ordering experience: choose what you need, send your order on WhatsApp, and our team confirms availability, delivery and payment with you.</p>
          <div className="about-actions">
            <Button asChild className="shop-button"><Link to="/shop" search={{ q: undefined, category: undefined }}>Browse products <ArrowRight size={16} /></Link></Button>
            <Button asChild variant="outline" className="outline-button"><Link to="/contact">Talk to us</Link></Button>
          </div>
        </div>
      </section>

      <section className="category-section about-values">
        <div className="section-heading">
          <div><p className="eyebrow">WHAT WE STAND FOR</p><h2>Why customers choose us</h2><span className="heading-rule" /></div>
        </div>
        <div className="values-grid">
          {values.map(({ title, text, Icon }) => (
            <div className="info-card" key={title}>
              <span className="info-icon"><Icon /></span>
              <h3>{title}</h3>
              <p>{text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="cta-band">
        <HeartHandshake size={28} />
        <div><h2>Need help choosing the right product?</h2><p>Message our team and we will point you in the right direction.</p></div>
        <Button asChild className="shop-button"><Link to="/contact">Contact us <ArrowRight size={16} /></Link></Button>
      </section>
    </SiteLayout>
  );
}