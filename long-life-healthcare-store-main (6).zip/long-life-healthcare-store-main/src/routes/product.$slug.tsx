import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, Heart, Minus, MessageCircle, Plus, ShieldCheck, ShoppingCart, Truck } from "lucide-react";

import { ProductCard } from "@/components/product-card";
import { SiteLayout } from "@/components/site-layout";
import { Button } from "@/components/ui/button";
import { addToCart, buildOrderMessage, naira, recordOrder, toggleWishlist, useCatalogReady, useProducts, useSettings, useWishlist, whatsappUrl } from "@/lib/store";

export const Route = createFileRoute("/product/$slug")({
  head: () => ({ meta: [{ title: "Product | Long Life Healthcare Supplies" }] }),
  component: ProductPage,
});

function ProductPage() {
  const { slug } = Route.useParams();
  const products = useProducts();
  const ready = useCatalogReady();
  const settings = useSettings();
  const wishlist = useWishlist();
  const [qty, setQty] = useState(1);

  const product = products.find((item) => item.slug === slug);

  if (!ready) {
    return (
      <SiteLayout>
        <section className="page-hero not-found" role="status"><p>Loading product...</p></section>
      </SiteLayout>
    );
  }

  if (!product) {
    return (
      <SiteLayout>
        <section className="page-hero not-found">
          <h1>Product not found</h1>
          <p>This product may have been removed or is no longer available.</p>
          <Button asChild className="shop-button"><Link to="/shop" search={{ q: undefined, category: undefined }}>Back to shop</Link></Button>
        </section>
      </SiteLayout>
    );
  }

  const soldOut = product.stock <= 0;
  const liked = wishlist.includes(product.id);
  const related = products.filter((item) => item.category === product.category && item.id !== product.id).slice(0, 4);
  const orderUrl = whatsappUrl(settings.whatsapp, buildOrderMessage(settings.storeName, [{ name: product.name, qty, price: product.price }]));

  return (
    <SiteLayout>
      <section className="page-hero compact">
        <nav className="breadcrumb" aria-label="Breadcrumb">
          <Link to="/">Home</Link><span>/</span>
          <Link to="/shop" search={{ q: undefined, category: undefined }}>Shop</Link><span>/</span>
          <Link to="/shop" search={{ q: undefined, category: product.category }}>{product.category}</Link><span>/</span>
          <span>{product.name}</span>
        </nav>
      </section>

      <section className="product-detail panel">
        <div className="detail-media">
          <img src={product.image} alt={product.name} width={640} height={640} />
        </div>
        <div className="detail-body">
          <Link className="detail-category" to="/shop" search={{ q: undefined, category: product.category }}>{product.category}</Link>
          <h1>{product.name}</h1>
          <p className="detail-price">{naira(product.price)}</p>
          <p className={`detail-stock ${soldOut ? "is-out" : product.stock <= 10 ? "is-low" : ""}`}>
            {soldOut ? "Out of stock" : product.stock <= 10 ? `Only ${product.stock} left in stock` : "In stock"}
          </p>
          <p className="detail-description">{product.description}</p>

          <div className="detail-buy">
            <div className="qty qty-large">
              <button type="button" aria-label="Decrease quantity" onClick={() => setQty((value) => Math.max(1, value - 1))}><Minus size={16} /></button>
              <b>{qty}</b>
              <button type="button" aria-label="Increase quantity" onClick={() => setQty((value) => value + 1)}><Plus size={16} /></button>
            </div>
            <Button className="add-cart-button detail-add" disabled={soldOut} onClick={() => addToCart(product, qty)}>
              <ShoppingCart size={16} /> Add to Cart
            </Button>
            <Button variant="ghost" size="icon" className={`wishlist-inline ${liked ? "is-liked" : ""}`} aria-label={liked ? "Remove from wishlist" : "Add to wishlist"} onClick={() => toggleWishlist(product.id)}>
              <Heart size={18} fill={liked ? "currentColor" : "none"} />
            </Button>
          </div>

          <a
            className="whatsapp-checkout detail-whatsapp"
            href={orderUrl}
            target="_blank"
            rel="noopener noreferrer"
            aria-disabled={soldOut}
            onClick={() => recordOrder({ customer: "", phone: "", address: "", summary: `1. ${product.name} x${qty} - ${naira(product.price * qty)}`, total: product.price * qty, source: "website" })}
          >
            <MessageCircle size={18} /> Order this on WhatsApp
          </a>

          <ul className="detail-points">
            <li><ShieldCheck size={16} /> 100% authentic and quality assured</li>
            <li><Truck size={16} /> Delivery confirmed on WhatsApp</li>
            <li><Check size={16} /> Payment and availability confirmed before dispatch</li>
          </ul>
        </div>
      </section>

      <div className="buybar">
        <div className="buybar-price"><span>Total</span><strong>{naira(product.price * qty)}</strong></div>
        <Button className="add-cart-button" disabled={soldOut} onClick={() => addToCart(product, qty)}>
          <ShoppingCart size={18} /> {soldOut ? "Out of stock" : "Add to Cart"}
        </Button>
        <a
          className="buybar-wa"
          href={orderUrl}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Order this on WhatsApp"
          aria-disabled={soldOut}
          onClick={() => recordOrder({ customer: "", phone: "", address: "", summary: `1. ${product.name} x${qty} - ${naira(product.price * qty)}`, total: product.price * qty, source: "website" })}
        >
          <MessageCircle size={22} />
        </a>
      </div>

      {related.length > 0 && (
        <section className="products-section related-section">
          <div className="section-heading product-heading">
            <div><p className="eyebrow">YOU MAY ALSO LIKE</p><h2>Related Products</h2></div>
          </div>
          <div className="product-grid shop-grid">
            {related.map((item) => <ProductCard key={item.id} product={item} />)}
          </div>
        </section>
      )}
    </SiteLayout>
  );
}