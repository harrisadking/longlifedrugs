import { useMemo, useState, type ChangeEvent, type FormEvent } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Eye, EyeOff, ImagePlus, Pencil, Plus, Search, Star, Trash2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { firebaseConfigured } from "@/lib/firebase";
import { uploadProductPhoto } from "@/lib/firebase-data";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import {
  CATEGORY_NAMES,
  deleteProduct,
  naira,
  notify,
  resetCatalog,
  saveProduct,
  setProductActive,
  slugify,
  useAllProducts,
  useCatalogReady,
  type CategoryName,
  type Product,
} from "@/lib/store";

export const Route = createFileRoute("/admin/products")({
  component: AdminProducts,
});

type Draft = {
  id?: string;
  name: string;
  category: CategoryName;
  price: string;
  stock: string;
  description: string;
  image: string;
  active: boolean;
  featured: boolean;
};

const emptyDraft: Draft = { name: "", category: "Pharmaceutical", price: "", stock: "0", description: "", image: "", active: true, featured: false };

const toDraft = (product: Product): Draft => ({
  id: product.id,
  name: product.name,
  category: product.category,
  price: String(product.price),
  stock: String(product.stock),
  description: product.description,
  image: product.image,
  active: product.active,
  featured: product.featured,
});

/** Shrinks an uploaded photo so it fits comfortably in browser storage. */
async function fileToDataUrl(file: File, max = 640): Promise<string> {
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, max / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(bitmap.width * scale);
  canvas.height = Math.round(bitmap.height * scale);
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Canvas is not available");
  context.fillStyle = "#fff";
  context.fillRect(0, 0, canvas.width, canvas.height);
  context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL("image/jpeg", 0.82);
}

function AdminProducts() {
  const products = useAllProducts();
  const ready = useCatalogReady();
  const [term, setTerm] = useState("");
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<Draft>(emptyDraft);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const visible = useMemo(() => {
    const needle = term.trim().toLowerCase();
    return needle ? products.filter((product) => `${product.name} ${product.category}`.toLowerCase().includes(needle)) : products;
  }, [products, term]);

  const startNew = () => {
    setDraft(emptyDraft);
    setError("");
    setOpen(true);
  };

  const startEdit = (product: Product) => {
    setDraft(toDraft(product));
    setError("");
    setOpen(true);
  };

  const onFile = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("Please choose an image file.");
      return;
    }
    setBusy(true);
    try {
      const image = await fileToDataUrl(file);
      setDraft((current) => ({ ...current, image }));
      setError("");
    } catch {
      setError("Could not read that image. Try a different file.");
    } finally {
      setBusy(false);
    }
  };

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (busy) return;
    const price = Number(draft.price);
    const stock = Number(draft.stock);
    if (!draft.name.trim()) return setError("Please enter a product name.");
    if (!Number.isFinite(price) || price < 0 || draft.price.trim() === "") return setError("Please enter a valid price.");
    if (!Number.isInteger(stock) || stock < 0) return setError("Stock must be a whole number, 0 or more.");
    if (!draft.image) return setError("Please add a product image (upload a photo or paste an image link).");

    setBusy(true);
    setError("");
    try {
      let image = draft.image;
      if (firebaseConfigured && image.startsWith("data:")) {
        // A newly chosen photo is uploaded first; its link is unique, so the old photo is never reused.
        const blob = await (await fetch(image)).blob();
        image = await uploadProductPhoto(new File([blob], `${slugify(draft.name)}.jpg`, { type: "image/jpeg" }));
      }
      const saved = await saveProduct({
        id: draft.id,
        name: draft.name.trim(),
        category: draft.category,
        price,
        stock,
        description: draft.description.trim(),
        image,
        active: draft.active,
        featured: draft.featured,
      });
      if (!saved) {
        setError(
          firebaseConfigured
            ? "Could not save this change. Check your connection and that you are signed in as staff, then try again."
            : "Your browser could not store this change (storage may be full). Try a smaller image or remove unused products.",
        );
        return;
      }
      notify(draft.id ? "Product updated." : "Product added.");
      setOpen(false);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not save this change. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  const toggleActive = async (product: Product) => {
    if (!(await setProductActive(product.id, !product.active))) notify("Could not update the product. Please try again.");
  };

  const remove = async (product: Product) => {
    if (!window.confirm(`Delete "${product.name}"? This cannot be undone.`)) return;
    notify((await deleteProduct(product.id)) ? "Product deleted." : "Could not delete the product. Please try again.");
  };

  const restore = async () => {
    if (!window.confirm("Restore the original sample products? Your product changes will be replaced.")) return;
    notify((await resetCatalog()) ? "Original products restored." : "Could not restore the products. Please try again.");
  };

  return (
    <>
      <div className="admin-heading with-action">
        <div><h1>Products</h1><p>{ready ? `${products.length} product${products.length === 1 ? "" : "s"}` : "Loading products..."} · hidden products do not show in the store.</p></div>
        <Button className="shop-button" onClick={startNew} disabled={!ready}><Plus size={16} /> Add product</Button>
      </div>

      <div className="admin-toolbar">
        <label className="search-box admin-search">
          <Search size={16} />
          <input aria-label="Search products" placeholder="Search products..." value={term} onChange={(event) => setTerm(event.target.value)} />
        </label>
        <button type="button" className="admin-ghost" onClick={() => void restore()}>Restore sample products</button>
      </div>

      <div className="admin-card table-card">
        <table className="admin-table">
          <thead>
            <tr><th>Product</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th><th aria-label="Actions" /></tr>
          </thead>
          <tbody>
            {visible.map((product) => (
              <tr key={product.id}>
                <td data-label="Product">
                  <div className="cell-product">
                    <img src={product.image} alt="" width={44} height={44} />
                    <div><strong>{product.name}</strong>{product.featured && <span className="pill pill-star"><Star size={11} /> Featured</span>}</div>
                  </div>
                </td>
                <td data-label="Category">{product.category}</td>
                <td data-label="Price">{naira(product.price)}</td>
                <td data-label="Stock"><b className={product.stock <= 0 ? "pill pill-red" : product.stock <= 10 ? "pill pill-amber" : "pill"}>{product.stock <= 0 ? "Out" : product.stock}</b></td>
                <td data-label="Status">{product.active ? <span className="pill pill-green">Visible</span> : <span className="pill">Hidden</span>}</td>
                <td className="row-actions">
                  <button type="button" aria-label={product.active ? `Hide ${product.name}` : `Show ${product.name}`} onClick={() => void toggleActive(product)}>
                    {product.active ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                  <button type="button" aria-label={`Edit ${product.name}`} onClick={() => startEdit(product)} disabled={!ready}><Pencil size={16} /></button>
                  <button type="button" className="danger" aria-label={`Delete ${product.name}`} onClick={() => void remove(product)}><Trash2 size={16} /></button>
                </td>
              </tr>
            ))}
            {visible.length === 0 && <tr><td colSpan={6} className="muted empty-row">{ready ? "No products match your search." : "Loading products..."}</td></tr>}
          </tbody>
        </table>
      </div>

      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent side="right" className="cart-sheet admin-sheet">
          <SheetHeader className="cart-sheet-header">
            <SheetTitle>{draft.id ? "Edit product" : "Add product"}</SheetTitle>
            <SheetDescription>Details shown to shoppers on the store.</SheetDescription>
          </SheetHeader>
          <form className="admin-form" onSubmit={submit}>
            <div className="image-field">
              <div className="image-preview">{draft.image ? <img src={draft.image} alt="Product preview" /> : <ImagePlus size={28} />}</div>
              <div className="image-controls">
                <label className="admin-ghost file-button">
                  <ImagePlus size={15} /> {busy ? "Processing..." : "Upload photo"}
                  <input type="file" accept="image/*" onChange={onFile} hidden />
                </label>
                <input
                  value={draft.image.startsWith("data:") ? "" : draft.image}
                  onChange={(event) => setDraft({ ...draft, image: event.target.value })}
                  placeholder={draft.image.startsWith("data:") ? "Uploaded photo in use" : "...or paste an image link"}
                  aria-label="Image link"
                />
              </div>
            </div>

            <label className="field">Name<input value={draft.name} onChange={(event) => setDraft({ ...draft, name: event.target.value })} placeholder="e.g. Surgical Face Masks" /></label>
            <label className="field">Category
              <select value={draft.category} onChange={(event) => setDraft({ ...draft, category: event.target.value as CategoryName })}>
                {CATEGORY_NAMES.map((name) => <option key={name} value={name}>{name}</option>)}
              </select>
            </label>
            <div className="field-row">
              <label className="field">Price (₦)<input value={draft.price} onChange={(event) => setDraft({ ...draft, price: event.target.value })} inputMode="decimal" placeholder="0" /></label>
              <label className="field">Stock<input value={draft.stock} onChange={(event) => setDraft({ ...draft, stock: event.target.value })} inputMode="numeric" placeholder="0" /></label>
            </div>
            <label className="field">Description<textarea rows={4} value={draft.description} onChange={(event) => setDraft({ ...draft, description: event.target.value })} placeholder="What should customers know?" /></label>
            <label className="check"><input type="checkbox" checked={draft.active} onChange={(event) => setDraft({ ...draft, active: event.target.checked })} /> Visible in store</label>
            <label className="check"><input type="checkbox" checked={draft.featured} onChange={(event) => setDraft({ ...draft, featured: event.target.checked })} /> Show on the home page (featured)</label>

            {error && <p className="form-error" role="alert">{error}</p>}
            <div className="form-actions">
              <Button type="button" variant="outline" className="outline-button" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" className="shop-button" disabled={busy}>{busy ? "Saving..." : draft.id ? "Save changes" : "Add product"}</Button>
            </div>
          </form>
        </SheetContent>
      </Sheet>
    </>
  );
}