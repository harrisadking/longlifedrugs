import { createFileRoute } from "@tanstack/react-router";

import { getOrigin } from "@/lib/site-url";
import { DEFAULT_PRODUCTS } from "@/lib/store";

const escapeXml = (value: string) =>
  value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");

// Public pages only. The cart and admin area are deliberately left out.
const STATIC_PATHS = ["/", "/shop", "/about", "/contact"];

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: ({ request }: { request: Request }) => {
        const origin = getOrigin(request);
        const paths = [...STATIC_PATHS, ...DEFAULT_PRODUCTS.filter((product) => product.active).map((product) => `/product/${product.slug}`)];
        const body = [
          "<?xml version=\"1.0\" encoding=\"UTF-8\"?>",
          "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">",
          ...paths.map((path) => `  <url><loc>${escapeXml(origin + path)}</loc></url>`),
          "</urlset>",
        ].join("\n");
        return new Response(body, {
          headers: {
            "Content-Type": "application/xml; charset=utf-8",
            "Cache-Control": "public, max-age=3600",
          },
        });
      },
    },
  },
});