import { useMemo, useState, type FormEvent } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Plus, Trash2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { deleteOrder, naira, notify, recordOrder, setOrderStatus, useOrders, type Order, type OrderStatus } from "@/lib/store";

export const Route = createFileRoute("/admin/orders")({
  component: AdminOrders,
});

const STATUSES: OrderStatus[] = ["New", "Confirmed", "Delivered", "Cancelled"];

const statusClass: Record<OrderStatus, string> = {
  New: "pill pill-amber",
  Confirmed: "pill pill-blue",
  Delivered: "pill pill-green",
  Cancelled: "pill pill-red",
};

const formatDate = (iso: string) =>
  new Date(iso).toLocaleString("en-NG", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });

function AdminOrders() {
  const orders = useOrders();
  const [filter, setFilter] = useState<"All" | OrderStatus>("All");
  const [open, setOpen] = useState(false);
  const [customer, setCustomer] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [items, setItems] = useState("");
  const [total, setTotal] = useState("");
  const [status, setStatus] = useState<OrderStatus>("New");
  const [error, setError] = useState("");

  const visible = useMemo(() => (filter === "All" ? orders : orders.filter((order) => order.status === filter)), [orders, filter]);

  const reset = () => {
    setCustomer("");
    setPhone("");
    setAddress("");
    setItems("");
    setTotal("");
    setStatus("New");
    setError("");
  };

  const submit = (event: FormEvent) => {
    event.preventDefault();
    const amount = Number(total);
    if (!items.trim()) return setError("Please list what was ordered.");
    if (!Number.isFinite(amount) || amount < 0 || total.trim() === "") return setError("Please enter the order total.");
    recordOrder({ customer: customer.trim(), phone: phone.trim(), address: address.trim(), summary: items.trim(), total: amount, status, source: "manual" });
    notify("Order added.");
    reset();
    setOpen(false);
  };

  const remove = (order: Order) => {
    if (window.confirm("Delete this order from the log?")) deleteOrder(order.id);
  };

  return (
    <>
      <div className="admin-heading with-action">
        <div><h1>Orders</h1><p>Track orders and update their status.</p></div>
        <Button className="shop-button" onClick={() => { reset(); setOpen(true); }}><Plus size={16} /> Add order</Button>
      </div>

      <p className="admin-banner">Orders sent from the website are logged in the browser the customer used. Add the orders you receive on WhatsApp here so you can follow them through to delivery.</p>

      <div className="filter-chips" role="tablist" aria-label="Filter orders by status">
        {(["All", ...STATUSES] as const).map((name) => (
          <button key={name} type="button" role="tab" aria-selected={filter === name} className={filter === name ? "chip chip-active" : "chip"} onClick={() => setFilter(name)}>
            {name}{name === "All" ? ` (${orders.length})` : ` (${orders.filter((order) => order.status === name).length})`}
          </button>
        ))}
      </div>

      {visible.length === 0 ? (
        <div className="admin-card"><p className="muted">No orders to show here yet.</p></div>
      ) : (
        <div className="order-list">
          {visible.map((order) => (
            <article className="admin-card order-card" key={order.id}>
              <header>
                <div>
                  <strong>{order.customer || "Customer"}</strong>
                  <span className="muted">{formatDate(order.createdAt)} · {order.source === "manual" ? "Added by staff" : "From website"}</span>
                </div>
                <b className={statusClass[order.status]}>{order.status}</b>
              </header>
              <pre className="order-summary">{order.summary}</pre>
              {(order.phone || order.address) && (
                <p className="order-contact">
                  {order.phone && <span>📞 {order.phone}</span>}
                  {order.address && <span>📍 {order.address}</span>}
                </p>
              )}
              <footer>
                <strong>{naira(order.total)}</strong>
                <div className="order-actions">
                  <select aria-label="Order status" value={order.status} onChange={(event) => setOrderStatus(order.id, event.target.value as OrderStatus)}>
                    {STATUSES.map((name) => <option key={name} value={name}>{name}</option>)}
                  </select>
                  <button type="button" className="admin-ghost danger" aria-label="Delete order" onClick={() => remove(order)}><Trash2 size={15} /></button>
                </div>
              </footer>
            </article>
          ))}
        </div>
      )}

      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent side="right" className="cart-sheet admin-sheet">
          <SheetHeader className="cart-sheet-header">
            <SheetTitle>Add order</SheetTitle>
            <SheetDescription>Log an order you received by WhatsApp or phone.</SheetDescription>
          </SheetHeader>
          <form className="admin-form" onSubmit={submit}>
            <label className="field">Customer name<input value={customer} onChange={(event) => setCustomer(event.target.value)} /></label>
            <div className="field-row">
              <label className="field">Phone<input value={phone} onChange={(event) => setPhone(event.target.value)} inputMode="tel" /></label>
              <label className="field">Total (₦)<input value={total} onChange={(event) => setTotal(event.target.value)} inputMode="decimal" /></label>
            </div>
            <label className="field">Delivery address<input value={address} onChange={(event) => setAddress(event.target.value)} /></label>
            <label className="field">Items ordered<textarea rows={4} value={items} onChange={(event) => setItems(event.target.value)} placeholder={"1. Nitrile Examination Gloves x2\n2. IV Infusion Set x5"} /></label>
            <label className="field">Status
              <select value={status} onChange={(event) => setStatus(event.target.value as OrderStatus)}>
                {STATUSES.map((name) => <option key={name} value={name}>{name}</option>)}
              </select>
            </label>
            {error && <p className="form-error" role="alert">{error}</p>}
            <div className="form-actions">
              <Button type="button" variant="outline" className="outline-button" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" className="shop-button">Add order</Button>
            </div>
          </form>
        </SheetContent>
      </Sheet>
    </>
  );
}