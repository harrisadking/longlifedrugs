import { useState, type FormEvent, type ReactNode } from "react";
import { createFileRoute, Link, Outlet } from "@tanstack/react-router";
import { ExternalLink, LayoutDashboard, Loader2, Lock, LogOut, Package, ReceiptText, Settings as SettingsIcon } from "lucide-react";

import { ToastHost } from "@/components/site-layout";
import { Button } from "@/components/ui/button";
import { signIn, signOut, useAuth } from "@/lib/auth";
import logoFull from "@/assets/long-life-logo-full.svg";
import logoMark from "@/assets/long-life-mark.svg";
import { useSettings } from "@/lib/store";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin | Long Life" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: AdminLayout,
});

function AdminLogin() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setBusy(true);
    const problem = await signIn(email, password);
    setBusy(false);
    setError(problem ?? "");
    if (!problem) setPassword("");
  };

  return (
    <main className="admin-login">
      <form className="admin-login-card" onSubmit={submit}>
        <img className="login-logo" src={logoFull} alt="Long Life" width={120} height={149} />
        <h1>Staff login</h1>
        <p>Sign in to manage products, orders and settings.</p>
        <input type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="Email" aria-label="Email" autoComplete="username" required autoFocus />
        <input type="password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Password" aria-label="Password" autoComplete="current-password" required />
        {error && <p className="form-error" role="alert">{error}</p>}
        <Button type="submit" className="shop-button" disabled={busy}>{busy ? "Signing in..." : "Sign in"}</Button>
        <Link to="/" className="admin-back">← Back to store</Link>
      </form>
    </main>
  );
}

function AdminMessage({ title, children }: { title: string; children: ReactNode }) {
  return (
    <main className="admin-login">
      <div className="admin-login-card admin-wide">
        <span className="info-icon"><Lock /></span>
        <h1>{title}</h1>
        {children}
        <Link to="/" className="admin-back">← Back to store</Link>
      </div>
    </main>
  );
}

function AdminLayout() {
  const auth = useAuth();
  const settings = useSettings();

  if (auth.status === "loading") {
    return (
      <main className="admin-login">
        <div className="admin-login-card" role="status" aria-live="polite">
          <Loader2 className="spin" />
          <p>Checking your login...</p>
        </div>
      </main>
    );
  }

  if (auth.status === "unconfigured") {
    return (
      <AdminMessage title="Connect your database">
        <p>The admin area needs your Firebase project. Add <b>VITE_FIREBASE_API_KEY</b>, <b>VITE_FIREBASE_AUTH_DOMAIN</b>, <b>VITE_FIREBASE_PROJECT_ID</b>, <b>VITE_FIREBASE_STORAGE_BUCKET</b>, <b>VITE_FIREBASE_MESSAGING_SENDER_ID</b> and <b>VITE_FIREBASE_APP_ID</b> to your environment, then rebuild and redeploy the site.</p>
      </AdminMessage>
    );
  }

  if (auth.status === "signed-out") return <AdminLogin />;

  if (auth.status === "no-access") {
    return (
      <AdminMessage title="No admin access">
        <p>You are signed in as <b>{auth.email}</b>, but this account is not on the staff list yet. Ask the store owner to add it, then sign in again.</p>
        <Button type="button" className="shop-button" onClick={() => void signOut()}>Sign out</Button>
      </AdminMessage>
    );
  }

  const linkProps = { className: "admin-nav-link", activeProps: { className: "admin-nav-link is-active" } } as const;

  return (
    <div className="admin-app">
      <header className="admin-top">
        <Link to="/admin" className="admin-title"><img className="admin-logo" src={logoMark} alt="" width={32} height={30} /><strong>{settings.storeName}</strong><em>Admin</em></Link>
        <div className="admin-top-actions">
          <Link to="/" className="admin-ghost" target="_blank"><ExternalLink size={15} /> <span>View store</span></Link>
          <button type="button" className="admin-ghost" onClick={() => void signOut()}><LogOut size={15} /> <span>Log out</span></button>
        </div>
      </header>
      <div className="admin-body">
        <nav className="admin-nav" aria-label="Admin sections">
          <Link to="/admin" activeOptions={{ exact: true }} {...linkProps}><LayoutDashboard size={17} /> <span>Dashboard</span></Link>
          <Link to="/admin/products" {...linkProps}><Package size={17} /> <span>Products</span></Link>
          <Link to="/admin/orders" {...linkProps}><ReceiptText size={17} /> <span>Orders</span></Link>
          <Link to="/admin/settings" {...linkProps}><SettingsIcon size={17} /> <span>Settings</span></Link>
        </nav>
        <main className="admin-content"><Outlet /></main>
      </div>
      <ToastHost />
    </div>
  );
}