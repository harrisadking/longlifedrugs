import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, FlaskConical, Headset, PackageCheck, Pill, ShieldCheck, Smile, Tag, Truck } from "lucide-react";

import { ProductCard } from "@/components/product-card";
import { SiteLayout } from "@/components/site-layout";
import { Button } from "@/components/ui/button";
import { CATEGORY_META, useCatalogReady, useProducts } from "@/lib/store";
import heroPhoto from "@/assets/longlife-hero.webp";
import heroPhotoSmall from "@/assets/longlife-hero-800.webp";
import careTeamPhoto from "@/assets/longlife-care-team.webp";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Long Life | Healthcare Supplies You Can Trust" },
      { name: "description", content: "Shop trusted pharmaceutical, medical, laboratory and dental supplies with Long Life." },
      { property: "og:title", content: "Long Life | Healthcare Supplies You Can Trust" },
      { property: "og:description", content: "Pharmaceutical, medical, laboratory and dental products — all in one place." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "preload", as: "image", href: heroPhotoSmall, media: "(max-width: 700px)" },
      { rel: "preload", as: "image", href: heroPhoto, media: "(min-width: 701px)" },
    ],
  }),
  component: HomePage,
});

const categoryIcons = { pharmaceutical: Pill, medical: PackageCheck, laboratory: FlaskConical, dental: Smile } as const;

const benefits = [
  { title: "Genuine Products", text: "100% authentic and quality assured.", Icon: ShieldCheck },
  { title: "Fast & Safe Delivery", text: "Your orders, on time and in good condition.", Icon: Truck },
  { title: "Expert Support", text: "Our team is here to help you.", Icon: Headset },
  { title: "Competitive Prices", text: "Great value for better care.", Icon: Tag },
];

function HomePage() {
  const products = useProducts();
  const ready = useCatalogReady();
  const featured = products.filter((product) => product.featured).slice(0, 10);
  const shown = featured.length ? featured : products.slice(0, 5);

  return (
    <SiteLayout>
      <section className="hero" aria-label="Long Life healthcare supplies">
        <img className="hero-photo" src={heroPhoto} srcSet={`${heroPhotoSmall} 800w, ${heroPhoto} 1600w`} sizes="(max-width: 700px) 100vw, 1400px" alt="Medicine bottles, tablets, capsules and a stethoscope" width={1600} height={640} fetchPriority="high" decoding="async" />
        <div className="hero-copy">
          <p className="eyebrow">QUALITY. TRUST. BETTER HEALTH.</p>
          <h1>Your Trusted Partner in<br /><span>Healthcare Supplies</span></h1>
          <p className="hero-description">Pharmaceuticals, medical &amp; surgical, laboratory<br className="desktop-break" /> and dental products — all in one place.</p>
          <Button asChild className="shop-button">
            <Link to="/shop" search={{ q: undefined, category: undefined }}>Shop Now <ArrowRight size={16} /></Link>
          </Button>
          <div className="slider-dots" aria-hidden="true"><i className="active" /><i /><i /></div>
        </div>
        <div className="trust-card">
          <ShieldCheck />
          <div><strong>Genuine Products</strong><span>100% authentic and<br />quality assured.</span></div>
        </div>
      </section>

      <section id="categories" className="category-section">
        <div className="section-heading">
          <div><p className="eyebrow">SHOP BY CATEGORY</p><h2>Explore Our Categories</h2><span className="heading-rule" /></div>
          <Link className="view-link" to="/shop" search={{ q: undefined, category: undefined }}>View All Products <ArrowRight size={14} /></Link>
        </div>
        <div className="category-grid">
          {CATEGORY_META.map(({ id, name, description, image, tint, color, icon }) => {
            const Icon = categoryIcons[id as keyof typeof categoryIcons];
            return (
              <Link key={id} to="/shop" search={{ q: undefined, category: name }} className={`category-card ${tint}`} aria-label={`Shop ${name}`}>
                <span className={`category-icon ${icon}`}><Icon size={24} strokeWidth={2.7} /></span>
                <h3>{name}</h3>
                <p>{description}</p>
                <span className={`category-shop ${color}`}>Shop Now <ArrowRight size={15} /></span>
                <img className="category-product" src={image} alt="" loading="lazy" width={400} height={640} />
              </Link>
            );
          })}
        </div>
      </section>

      <section id="products" className="products-section">
        <div className="section-heading product-heading">
          <div><p className="eyebrow">FEATURED PRODUCTS</p><h2>Popular Products</h2></div>
          <Link className="view-link" to="/shop" search={{ q: undefined, category: undefined }}>View All <ArrowRight size={14} /></Link>
        </div>
        <div className="product-grid">
          {shown.map((product) => <ProductCard key={product.id} product={product} />)}
          {!ready && <p className="no-results" role="status">Loading products...</p>}
          {ready && shown.length === 0 && <p className="no-results">No products available right now. Please check back soon.</p>}
        </div>
      </section>

      <section id="why" className="why-section">
        <div className="care-photo"><img src={careTeamPhoto} alt="Healthcare professional reviewing patient information" width={1024} height={1024} loading="lazy" /></div>
        <div className="why-title"><p className="eyebrow">WHY CHOOSE US</p><h2>Reliable Supply for<br />a Healthier Tomorrow</h2></div>
        <div className="benefits">
          {benefits.map(({ title, text, Icon }) => (
            <div className="benefit" key={title}><Icon /><h3>{title}</h3><p>{text}</p></div>
          ))}
        </div>
      </section>
    </SiteLayout>
  );
}