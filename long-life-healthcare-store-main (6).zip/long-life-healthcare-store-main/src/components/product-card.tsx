import { Link } from "@tanstack/react-router";
import { Heart, ShoppingCart } from "lucide-react";

import { Button } from "@/components/ui/button";
import { addToCart, naira, toggleWishlist, useCart, useWishlist, type Product } from "@/lib/store";

export function ProductCard({ product }: { product: Product }) {
  const wishlist = useWishlist();
  const cart = useCart();
  const liked = wishlist.includes(product.id);
  const inCart = cart.find((line) => line.id === product.id);
  const soldOut = product.stock <= 0;

  return (
    <article className="product-card">
      <div className="product-image">
        <Link to="/product/$slug" params={{ slug: product.slug }} aria-label={`View ${product.name}`}>
          <img src={product.image} alt={product.name} loading="lazy" decoding="async" width={640} height={640} />
        </Link>
        {soldOut ? <span className="stock-badge stock-out">Out of stock</span> : product.stock <= 10 ? <span className="stock-badge stock-low">Only {product.stock} left</span> : null}
        <Button
          variant="ghost"
          size="icon"
          className={`wishlist-button ${liked ? "is-liked" : ""}`}
          aria-label={liked ? `Remove ${product.name} from wishlist` : `Add ${product.name} to wishlist`}
          onClick={() => toggleWishlist(product.id)}
        >
          <Heart size={18} fill={liked ? "currentColor" : "none"} />
        </Button>
      </div>
      <div className="product-info">
        <h3><Link to="/product/$slug" params={{ slug: product.slug }}>{product.name}</Link></h3>
        <span className="product-category">{product.category}</span>
        <strong className="product-price">{naira(product.price)}</strong>
        <Button className="add-cart-button" disabled={soldOut} onClick={() => addToCart(product)}>
          <ShoppingCart size={14} /> {soldOut ? "Out of stock" : inCart ? `Add more (${inCart.qty})` : "Add to Cart"}
        </Button>
      </div>
    </article>
  );
}