import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { ArrowRight, Check, CircleUserRound, House, MapPin, Mail, Menu, MessageCircle, Minus, Phone, Plus, Search, ShieldCheck, ShoppingBag, ShoppingCart, Store, Trash2, X } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { placeOrder } from "@/lib/db";
import logoHorizontal from "@/assets/long-life-logo.svg";
import {
  CATEGORY_NAMES,
  buildOrderMessage,
  cartCount,
  cartTotal,
  changeCartQty,
  clearCart,
  dismissToast,
  naira,
  removeCartLine,
  useCart,
  useSettings,
  useToast,
  whatsappUrl,
  type CartLine,
} from "@/lib/store";

export function Brand({ footer = false }: { footer?: boolean }) {
  return (
    <Link to="/" className="brand" aria-label="Long Life home" data-footer={footer || undefined}>
      <img className="brand-logo" src={logoHorizontal} alt="Long Life" width={938} height={369} decoding="async" />
    </Link>
  );
}

/* ------------------------------------------------------------ cart pieces */

export function CartLines({ lines }: { lines: CartLine[] }) {
  return (
    <ul className="ck-lines">
      {lines.map((line) => (
        <li key={line.id} className="ck-line">
          <img className="ck-thumb" src={line.image} alt="" width={80} height={80} />
          <div className="ck-info">
            <strong>{line.name}</strong>
            <span>{naira(line.price)} each</span>
          </div>
          <div className="ck-qty" role="group" aria-label={`Quantity of ${line.name}`}>
            <button type="button" aria-label={`Decrease ${line.name}`} onClick={() => changeCartQty(line.id, -1)}><Minus size={14} /></button>
            <b aria-live="polite">{line.qty}</b>
            <button type="button" aria-label={`Increase ${line.name}`} onClick={() => changeCartQty(line.id, 1)}><Plus size={14} /></button>
          </div>
          <strong className="ck-line-total">{naira(line.price * line.qty)}</strong>
          <button type="button" className="ck-remove" aria-label={`Remove ${line.name}`} onClick={() => removeCartLine(line.id)}>
            <Trash2 size={16} />
          </button>
        </li>
      ))}
    </ul>
  );
}

export function CheckoutForm({ lines }: { lines: CartLine[] }) {
  const settings = useSettings();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [note, setNote] = useState("");
  const total = cartTotal(lines);
  const count = cartCount(lines);

  const url = useMemo(
    () => whatsappUrl(settings.whatsapp, buildOrderMessage(settings.storeName, lines, { name, phone, address, note })),
    [settings.whatsapp, settings.storeName, lines, name, phone, address, note],
  );

  return (
    <div className="ck-card ck-summary">
      <h2 className="ck-h">Order summary</h2>
      <dl className="ck-rows">
        <div><dt>Items ({count})</dt><dd>{naira(total)}</dd></div>
        <div><dt>Delivery</dt><dd className="ck-muted">Arranged on WhatsApp</dd></div>
      </dl>
      <div className="ck-total"><span>Total</span><strong>{naira(total)}</strong></div>

      <h3 className="ck-sub">Delivery details <small>optional</small></h3>
      <div className="ck-fields">
        <label className="ck-field"><span>Full name</span>
          <input value={name} onChange={(event) => setName(event.target.value)} placeholder="e.g. Amaka Obi" autoComplete="name" />
        </label>
        <label className="ck-field"><span>Phone number</span>
          <input value={phone} onChange={(event) => setPhone(event.target.value)} placeholder="e.g. 0803 000 0000" autoComplete="tel" inputMode="tel" />
        </label>
        <label className="ck-field"><span>Delivery address</span>
          <textarea rows={2} value={address} onChange={(event) => setAddress(event.target.value)} placeholder="Street, area and city" autoComplete="street-address" />
        </label>
        <label className="ck-field"><span>Note for the team</span>
          <textarea rows={2} value={note} onChange={(event) => setNote(event.target.value)} placeholder="Anything we should know?" />
        </label>
      </div>

      <a
        className="ck-wa"
        href={url}
        target="_blank"
        rel="noopener noreferrer"
        onClick={() => void placeOrder(lines, { name, phone, address, note })}
      >
        <MessageCircle size={20} /> Order on WhatsApp
      </a>
      <ul className="ck-trust">
        <li><MessageCircle size={16} /><span>No online payment. We confirm availability, delivery and payment with you on WhatsApp.</span></li>
        <li><ShieldCheck size={16} /><span>Genuine, quality-assured stock from licensed suppliers.</span></li>
      </ul>
    </div>
  );
}

/* ------------------------------------------------------------------ toast */

export function ToastHost() {
  const toast = useToast();

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(dismissToast, 2600);
    return () => window.clearTimeout(timer);
  }, [toast]);

  if (!toast) return null;
  return (
    <div className="notice" role="status" key={toast.id}>
      {toast.text}
      <button aria-label="Dismiss" onClick={dismissToast}><X size={15} /></button>
    </div>
  );
}

/* ----------------------------------------------------------------- layout */

export function SiteLayout({ children }: { children: ReactNode }) {
  const settings = useSettings();
  const cart = useCart();
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (state) => state.location.pathname });

  const [menuOpen, setMenuOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [query, setQuery] = useState("");
  const [subscribed, setSubscribed] = useState(false);
  const [bump, setBump] = useState(0);

  const count = cartCount(cart);

  useEffect(() => {
    if (count > 0) setBump((value) => value + 1);
  }, [count]);

  useEffect(() => {
    setMenuOpen(false);
    window.scrollTo({ top: 0 });
  }, [pathname]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Scroll-reveal for anything that appears on the page, now or later.
  useEffect(() => {
    if (typeof IntersectionObserver === "undefined") return;
    const selector = ".section-heading, .page-hero, .filter-chips, .category-card, .product-card, .why-section, .benefit, .info-card, .panel, .footer";
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("motion-visible");
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.08, rootMargin: "0px 0px -24px 0px" },
    );
    let frame = 0;
    const scan = () => {
      frame = 0;
      document.querySelectorAll<HTMLElement>(selector).forEach((element, index) => {
        if (element.dataset["reveal"]) return;
        element.dataset["reveal"] = "1";
        // Content already on screen stays visible: only items below the fold animate in.
        if (element.getBoundingClientRect().top < window.innerHeight) return;
        element.classList.add("motion-item");
        element.style.setProperty("--stagger", `${(index % 5) * 70}ms`);
        io.observe(element);
      });
    };
    const mutations = new MutationObserver(() => {
      if (!frame) frame = window.requestAnimationFrame(scan);
    });
    document.documentElement.classList.add("motion-enabled");
    scan();
    mutations.observe(document.body, { childList: true, subtree: true });
    return () => {
      mutations.disconnect();
      io.disconnect();
      if (frame) window.cancelAnimationFrame(frame);
      document.documentElement.classList.remove("motion-enabled");
    };
  }, []);

  const navClass = (active: boolean) => (active ? "nav-active" : undefined);
  const onHome = pathname === "/";
  const onShop = pathname.startsWith("/shop") || pathname.startsWith("/product");
  const onProduct = pathname.startsWith("/product");
  const chatUrl = whatsappUrl(settings.whatsapp, `Hello ${settings.storeName}, I have a question about your products.`);

  const submitSearch = (event: FormEvent) => {
    event.preventDefault();
    const q = query.trim();
    navigate({ to: "/shop", search: { q: q || undefined, category: undefined } });
  };

  return (
    <div className={`storefront${onProduct ? " has-buybar" : ""}`}>
      <header className={`topbar ${scrolled ? "is-scrolled" : ""}`}>
        <Brand />
        <nav className={`main-nav ${menuOpen ? "nav-open" : ""}`} aria-label="Main navigation">
          <Link to="/" className={navClass(onHome)} aria-current={onHome ? "page" : undefined}>Home</Link>
          <Link to="/shop" search={{ q: undefined, category: undefined }} className={navClass(onShop)} aria-current={onShop ? "page" : undefined}>Shop</Link>
          <Link to="/about" className={navClass(pathname === "/about")}>About Us</Link>
          <Link to="/contact" className={navClass(pathname === "/contact")}>Contact</Link>
        </nav>
        <form className="search-box" role="search" onSubmit={submitSearch}>
          <Search size={17} />
          <input aria-label="Search products" placeholder="Search products..." value={query} onChange={(event) => setQuery(event.target.value)} />
          {query && (
            <button type="button" aria-label="Clear search" onClick={() => setQuery("")}><X size={14} /></button>
          )}
        </form>
        <Button asChild variant="ghost" className="account-button" aria-label="Contact us">
          <Link to="/contact"><CircleUserRound /><span>Help</span></Link>
        </Button>
        <div className="cart-wrap">
          <Button variant="ghost" className="cart-button" aria-label={`Open cart, ${count} items`} onClick={() => setCartOpen(true)}>
            <ShoppingCart />
            <span>Cart</span>
            <b key={bump} className={bump ? "badge-bump" : ""}>{count}</b>
          </Button>
        </div>
        <Button variant="ghost" size="icon" className="mobile-menu" aria-label="Toggle menu" aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <X /> : <Menu />}
        </Button>
      </header>

      <main id="top">{children}</main>

      <footer id="contact" className="footer">
        <div className="footer-main">
          <div className="footer-brand"><Brand footer /><small>© 2026 {settings.storeName}. All rights reserved.</small></div>
          <div className="newsletter">
            <h3>Subscribe for updates</h3>
            <p>Get the latest products, offers and health tips.</p>
            <form onSubmit={(event) => { event.preventDefault(); setSubscribed(true); }}>
              <input type="email" placeholder="Your email address" aria-label="Your email address" required />
              <Button aria-label="Subscribe"><ArrowRight size={17} /></Button>
            </form>
            {subscribed && <span className="subscribe-success"><Check size={13} /> You're subscribed.</span>}
          </div>
          <div className="footer-links">
            <h3>Quick Links</h3>
            <Link to="/">Home</Link>
            <Link to="/shop" search={{ q: undefined, category: undefined }}>Shop</Link>
            <Link to="/about">About Us</Link>
            <Link to="/contact">Contact</Link>
            <Link to="/cart">Cart</Link>
          </div>
          <div className="footer-links">
            <h3>Categories</h3>
            {CATEGORY_NAMES.map((name) => (
              <Link key={name} to="/shop" search={{ q: undefined, category: name }}>{name}</Link>
            ))}
          </div>
          <div className="footer-contact">
            <h3>Contact Us</h3>
            <a href={`tel:${settings.phone.replace(/[^+\d]/g, "")}`}><Phone /> {settings.phone}</a>
            <a href={whatsappUrl(settings.whatsapp, `Hello ${settings.storeName}, I have a question.`)} target="_blank" rel="noopener noreferrer"><MessageCircle /> WhatsApp us</a>
            <a href={`mailto:${settings.email}`}><Mail /> {settings.email}</a>
            <span><MapPin /> {settings.address}</span>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© 2026 {settings.storeName}. All rights reserved.</span>
          <Link to="/admin" className="admin-link">Staff login</Link>
        </div>
      </footer>

      <nav className="tabbar" aria-label="Quick navigation">
        <Link to="/" className={onHome ? "is-active" : undefined} aria-label="Home"><House size={22} /><span>Home</span></Link>
        <Link to="/shop" search={{ q: undefined, category: undefined }} className={onShop ? "is-active" : undefined} aria-label="Shop"><Store size={22} /><span>Shop</span></Link>
        <button type="button" className={pathname === "/cart" ? "is-active" : undefined} aria-label={`Open cart, ${count} items`} onClick={() => setCartOpen(true)}>
          <ShoppingBag size={22} /><span>Cart</span>
          {count > 0 && <b className="tabbar-badge">{count}</b>}
        </button>
        <a href={chatUrl} target="_blank" rel="noopener noreferrer" className="tab-chat" aria-label="Chat on WhatsApp"><MessageCircle size={22} /><span>Chat</span></a>
      </nav>

      {pathname !== "/cart" && (
        <a className="whatsapp-fab" href={chatUrl} target="_blank" rel="noopener noreferrer" aria-label="Chat with us on WhatsApp">
          <MessageCircle size={26} />
          <span>Chat with us</span>
        </a>
      )}

      <Sheet open={cartOpen} onOpenChange={setCartOpen}>
        <SheetContent side="right" className="cart-sheet">
          <SheetHeader className="cart-sheet-header">
            <SheetTitle>Your cart</SheetTitle>
            <SheetDescription>{count ? `${count} item${count === 1 ? "" : "s"} ready to order` : "Nothing here yet"}</SheetDescription>
          </SheetHeader>
          {cart.length === 0 ? (
            <div className="cart-empty">
              <ShoppingCart size={36} />
              <p>Your cart is empty.</p>
              <Button asChild className="shop-button" onClick={() => setCartOpen(false)}>
                <Link to="/shop" search={{ q: undefined, category: undefined }}>Browse products <ArrowRight size={16} /></Link>
              </Button>
            </div>
          ) : (
            <>
              <div className="ck-sheet-body"><CartLines lines={cart} /></div>
              <div className="ck-sheet-footer">
                <div className="ck-total"><span>Subtotal</span><strong>{naira(cartTotal(cart))}</strong></div>
                <Link to="/cart" className="ck-primary" onClick={() => setCartOpen(false)}>Go to checkout <ArrowRight size={18} /></Link>
                <button type="button" className="ck-clear" onClick={clearCart}>Clear cart</button>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>

      <ToastHost />
    </div>
  );
}