/**
 * Long Life data layer.
 *
 * Everything the storefront and the admin area read or write goes through this
 * file. Data is kept in the visitor's browser (localStorage) so the site works
 * with no backend. To move to a real database later, replace the
 * `createStore(...)` calls and the action functions below; pages only use the
 * hooks and actions exported from here.
 */
import { useSyncExternalStore } from "react";

import { firebaseConfigured } from "@/lib/firebase";
import { saveCatalog, watchCatalog } from "@/lib/firebase-data";

import paracetamolPhoto from "@/assets/products/paracetamol.webp";
import glovesPhoto from "@/assets/products/gloves.webp";
import tubesPhoto from "@/assets/products/tubes.webp";
import handpiecePhoto from "@/assets/products/handpiece.webp";
import ivSetPhoto from "@/assets/products/iv-set.webp";
import catPharmaceutical from "@/assets/products/cat-pharmaceutical.webp";
import catMedical from "@/assets/products/cat-medical.webp";
import catLaboratory from "@/assets/products/cat-laboratory.webp";
import catDental from "@/assets/products/cat-dental.webp";

/* ------------------------------------------------------------------ types */

export type CategoryName = "Pharmaceutical" | "Medical & Surgical" | "Laboratory" | "Dental";

export type Product = {
  id: string;
  slug: string;
  name: string;
  category: CategoryName;
  price: number;
  stock: number;
  description: string;
  image: string;
  active: boolean;
  featured: boolean;
};

export type CartLine = { id: string; name: string; price: number; qty: number; image: string };

export type OrderStatus = "New" | "Confirmed" | "Delivered" | "Cancelled";

export type Order = {
  id: string;
  createdAt: string;
  customer: string;
  phone: string;
  address: string;
  summary: string;
  total: number;
  status: OrderStatus;
  source: "website" | "manual";
};

export type Settings = {
  storeName: string;
  whatsapp: string;
  phone: string;
  email: string;
  address: string;
  hours: string;
  adminPasscode: string;
};

/* --------------------------------------------------------------- defaults */

export const DEFAULT_SETTINGS: Settings = {
  storeName: "Long Life",
  whatsapp: "2348030460998",
  phone: "+234 803 046 0998",
  email: "info@longlifedrugs.com",
  address: "Lagos, Nigeria",
  hours: "Mon – Sat, 8:00am – 6:00pm",
  adminPasscode: "",
};

export const CATEGORY_META = [
  { id: "pharmaceutical", name: "Pharmaceutical" as CategoryName, description: "Original and trusted medicines for a healthier you.", image: catPharmaceutical, tint: "category-pink", color: "tone-red", icon: "category-icon-red" },
  { id: "medical", name: "Medical & Surgical" as CategoryName, description: "Essential equipment and supplies for better care.", image: catMedical, tint: "category-blue", color: "tone-blue", icon: "category-icon-blue" },
  { id: "laboratory", name: "Laboratory" as CategoryName, description: "Accurate results. Better decisions.", image: catLaboratory, tint: "category-purple", color: "tone-purple", icon: "category-icon-purple" },
  { id: "dental", name: "Dental" as CategoryName, description: "Complete dental care solutions.", image: catDental, tint: "category-green", color: "tone-green", icon: "category-icon-green" },
];

export const CATEGORY_NAMES: CategoryName[] = CATEGORY_META.map((category) => category.name);

export const DEFAULT_PRODUCTS: Product[] = [
  { id: "p-paracetamol", slug: "paracetamol-500mg", name: "Paracetamol 500mg", category: "Pharmaceutical", price: 2500, stock: 120, description: "Trusted pain and fever relief tablets. Genuine, quality-assured stock sourced from licensed suppliers.", image: paracetamolPhoto, active: true, featured: true },
  { id: "p-gloves", slug: "nitrile-examination-gloves", name: "Nitrile Examination Gloves", category: "Medical & Surgical", price: 8000, stock: 80, description: "Powder-free nitrile gloves for clinics, labs and home care. Comfortable fit with a reliable barrier.", image: glovesPhoto, active: true, featured: true },
  { id: "p-tubes", slug: "vacutainer-blood-collection-tube", name: "Vacutainer Blood Collection Tube", category: "Laboratory", price: 15000, stock: 60, description: "Sterile blood collection tubes for accurate sample handling in laboratories and clinics.", image: tubesPhoto, active: true, featured: true },
  { id: "p-handpiece", slug: "dental-handpiece-high-speed", name: "Dental Handpiece (High Speed)", category: "Dental", price: 45000, stock: 15, description: "High-speed dental handpiece built for precision and durability in everyday practice.", image: handpiecePhoto, active: true, featured: true },
  { id: "p-ivset", slug: "iv-infusion-set", name: "IV Infusion Set", category: "Medical & Surgical", price: 6500, stock: 200, description: "Sterile single-use IV infusion set with a smooth, controllable flow.", image: ivSetPhoto, active: true, featured: true },
];

const EMPTY_CART: CartLine[] = [];
const EMPTY_ORDERS: Order[] = [];
const EMPTY_WISHLIST: string[] = [];

/* ------------------------------------------------------------- store core */

type Store<T> = {
  get: () => T;
  set: (next: T) => boolean;
  subscribe: (listener: () => void) => () => void;
  fallback: T;
};

function createStore<T>(key: string, fallback: T, options: { session?: boolean; persist?: boolean } = {}): Store<T> {
  const { session = false, persist = true } = options;
  let cache: T = fallback;
  let loaded = !persist;
  const listeners = new Set<() => void>();

  const storage = (): Storage | null => {
    if (typeof window === "undefined") return null;
    try {
      return session ? window.sessionStorage : window.localStorage;
    } catch {
      return null;
    }
  };

  const load = () => {
    loaded = true;
    try {
      const raw = storage()?.getItem(key);
      cache = raw ? (JSON.parse(raw) as T) : fallback;
    } catch {
      cache = fallback;
    }
  };

  const emit = () => listeners.forEach((listener) => listener());

  const onStorage = (event: StorageEvent) => {
    if (event.key !== key) return;
    load();
    emit();
  };

  return {
    fallback,
    get() {
      if (typeof window === "undefined") return fallback;
      if (!loaded) load();
      return cache;
    },
    set(next) {
      cache = next;
      loaded = true;
      let saved = true;
      if (persist) {
        try {
          storage()?.setItem(key, JSON.stringify(next));
        } catch {
          saved = false; // storage full or unavailable: the value only lives in memory
        }
      }
      emit();
      return saved;
    },
    subscribe(listener) {
      listeners.add(listener);
      if (listeners.size === 1 && typeof window !== "undefined") window.addEventListener("storage", onStorage);
      return () => {
        listeners.delete(listener);
        if (listeners.size === 0 && typeof window !== "undefined") window.removeEventListener("storage", onStorage);
      };
    },
  };
}

function useStore<T>(store: Store<T>): T {
  return useSyncExternalStore(store.subscribe, store.get, () => store.fallback);
}

// With Firebase configured, the live database is the only source of truth: nothing is cached
// in the browser, so shoppers never see stale products before the current ones arrive.
const catalogStore = createStore<Product[] | null>("longlife-catalog-v1", null, { persist: !firebaseConfigured });
const catalogReadyStore = createStore<boolean>("longlife-catalog-ready", !firebaseConfigured, { persist: false });
const cartStore = createStore<CartLine[]>("longlife-cart-v2", EMPTY_CART);
const ordersStore = createStore<Order[]>("longlife-orders-v1", EMPTY_ORDERS);
const wishlistStore = createStore<string[]>("longlife-wishlist-v1", EMPTY_WISHLIST);
const settingsStore = createStore<Settings | null>("longlife-settings-v1", null, { persist: !firebaseConfigured });
const toastStore = createStore<{ id: number; text: string } | null>("longlife-toast", null, { persist: false });

/* ------------------------------------------------------------------ hooks */

const NO_PRODUCTS: Product[] = [];

/** False until the current catalog has been loaded from the database. */
export function useCatalogReady(): boolean {
  return useStore(catalogReadyStore);
}

export function useAllProducts(): Product[] {
  const ready = useCatalogReady();
  const stored = useStore(catalogStore);
  if (!ready) return NO_PRODUCTS;
  return stored ?? DEFAULT_PRODUCTS;
}

/** Products visible to shoppers (hidden items are filtered out). */
export function useProducts(): Product[] {
  const all = useAllProducts();
  return all.filter((product) => product.active);
}

export function useCart(): CartLine[] {
  return useStore(cartStore);
}

export function useOrders(): Order[] {
  return useStore(ordersStore);
}

export function useWishlist(): string[] {
  return useStore(wishlistStore);
}

export function useSettings(): Settings {
  const stored = useStore(settingsStore);
  if (!stored) return DEFAULT_SETTINGS;
  return {
    ...DEFAULT_SETTINGS,
    ...stored,
    email: stored.email.replace(/@longlife\.com\b/gi, "@longlifedrugs.com"),
  };
}

export function useToast() {
  return useStore(toastStore);
}

/* ---------------------------------------------------------------- helpers */

export const naira = (value: number) => `₦${Math.round(value).toLocaleString("en-NG")}`;

export const slugify = (value: string) =>
  value
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "") || "product";

const uid = (prefix: string) => `${prefix}-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;

export const cartCount = (cart: CartLine[]) => cart.reduce((sum, line) => sum + line.qty, 0);
export const cartTotal = (cart: CartLine[]) => cart.reduce((sum, line) => sum + line.qty * line.price, 0);

export function whatsappUrl(number: string, text: string) {
  return `https://wa.me/${number.replace(/\D/g, "")}?text=${encodeURIComponent(text)}`;
}

export function orderSummary(lines: Pick<CartLine, "name" | "qty" | "price">[]) {
  return lines.map((line, index) => `${index + 1}. ${line.name} x${line.qty} - ${naira(line.price * line.qty)}`).join("\n");
}

export function buildOrderMessage(
  storeName: string,
  lines: Pick<CartLine, "name" | "qty" | "price">[],
  details: { name?: string; phone?: string; address?: string; note?: string } = {},
) {
  const total = lines.reduce((sum, line) => sum + line.qty * line.price, 0);
  const extra = [
    details.name?.trim() ? `Name: ${details.name.trim()}` : "",
    details.phone?.trim() ? `Phone: ${details.phone.trim()}` : "",
    details.address?.trim() ? `Delivery address: ${details.address.trim()}` : "",
    details.note?.trim() ? `Note: ${details.note.trim()}` : "",
  ].filter(Boolean);
  return [
    `Hello ${storeName}, I would like to place an order:`,
    "",
    orderSummary(lines),
    "",
    `Total: ${naira(total)}`,
    ...(extra.length ? ["", ...extra] : []),
  ].join("\n");
}

/* ---------------------------------------------------------------- actions */

export function notify(text: string) {
  toastStore.set({ id: Date.now(), text });
}

export function dismissToast() {
  toastStore.set(null);
}

// cart
export function addToCart(product: Product, qty = 1) {
  const cart = cartStore.get();
  const existing = cart.find((line) => line.id === product.id);
  cartStore.set(
    existing
      ? cart.map((line) => (line.id === product.id ? { ...line, qty: line.qty + qty } : line))
      : [...cart, { id: product.id, name: product.name, price: product.price, qty, image: product.image }],
  );
  notify(`${product.name} added to cart.`);
}

export function changeCartQty(id: string, delta: number) {
  cartStore.set(
    cartStore.get().flatMap((line) => {
      if (line.id !== id) return [line];
      const qty = line.qty + delta;
      return qty > 0 ? [{ ...line, qty }] : [];
    }),
  );
}

export function removeCartLine(id: string) {
  cartStore.set(cartStore.get().filter((line) => line.id !== id));
}

export function clearCart() {
  cartStore.set(EMPTY_CART);
}

// wishlist
export function toggleWishlist(id: string) {
  const list = wishlistStore.get();
  wishlistStore.set(list.includes(id) ? list.filter((item) => item !== id) : [...list, id]);
}

// orders
export function recordOrder(input: Omit<Order, "id" | "createdAt" | "status"> & { status?: OrderStatus | undefined }) {
  const { status = "New", ...rest } = input;
  const order: Order = { id: uid("ord"), createdAt: new Date().toISOString(), ...rest, status };
  ordersStore.set([order, ...ordersStore.get()]);
  return order;
}

export function setOrderStatus(id: string, status: OrderStatus) {
  ordersStore.set(ordersStore.get().map((order) => (order.id === id ? { ...order, status } : order)));
}

export function deleteOrder(id: string) {
  ordersStore.set(ordersStore.get().filter((order) => order.id !== id));
}

// catalog (admin)
function currentCatalog(): Product[] {
  return catalogStore.get() ?? DEFAULT_PRODUCTS;
}

function currentSettings(): Settings {
  return { ...DEFAULT_SETTINGS, ...(settingsStore.get() ?? {}) };
}

// Bundled sample photos get a new file name on every build, so they are stored as a stable marker.
const DEFAULT_IMAGE_PREFIX = "default:";
const defaultImageIds = new Map(DEFAULT_PRODUCTS.map((product) => [product.image, product.id]));
const defaultImagesById = new Map(DEFAULT_PRODUCTS.map((product) => [product.id, product.image]));

const encodeProducts = (products: Product[]): Product[] =>
  products.map((product) => {
    const id = defaultImageIds.get(product.image);
    return id ? { ...product, image: `${DEFAULT_IMAGE_PREFIX}${id}` } : product;
  });

const decodeProducts = (products: Product[]): Product[] =>
  products.map((product) =>
    product.image.startsWith(DEFAULT_IMAGE_PREFIX)
      ? { ...product, image: defaultImagesById.get(product.image.slice(DEFAULT_IMAGE_PREFIX.length)) ?? "" }
      : product,
  );

/**
 * Starts listening to the live catalog. Call once from the root component.
 * Every change (including the admin's own) arrives through this listener, so the
 * screen always shows what is actually saved.
 */
export function startCatalogSync(): () => void {
  if (!firebaseConfigured || typeof window === "undefined") return () => {};
  const stop = watchCatalog(
    (catalog) => {
      catalogStore.set(catalog?.products ? decodeProducts(catalog.products) : null);
      settingsStore.set(catalog?.settings ? { ...DEFAULT_SETTINGS, ...catalog.settings } : null);
      catalogReadyStore.set(true);
    },
    (error) => {
      console.error("Could not load the catalog", error);
      catalogReadyStore.set(true);
    },
  );
  return () => stop?.();
}

/** Saves the catalog (and optionally settings). Resolves false if it could not be saved. */
async function commitCatalog(products: Product[] | null, settings?: Settings): Promise<boolean> {
  if (!firebaseConfigured) {
    const savedCatalog = catalogStore.set(products);
    return settings ? settingsStore.set(settings) && savedCatalog : savedCatalog;
  }
  if (!catalogReadyStore.get()) return false; // never overwrite the database before it has loaded
  try {
    await saveCatalog(encodeProducts(products ?? DEFAULT_PRODUCTS), settings ?? currentSettings());
    return true;
  } catch (error) {
    console.error("Could not save the catalog", error);
    return false;
  }
}

/** Resolves false if the change could not be saved. */
export async function saveProduct(input: Omit<Product, "id" | "slug"> & { id?: string | undefined }): Promise<boolean> {
  const catalog = currentCatalog();
  const base = slugify(input.name);
  const uniqueSlug = (ownId?: string) => {
    let slug = base;
    let n = 2;
    while (catalog.some((product) => product.slug === slug && product.id !== ownId)) slug = `${base}-${n++}`;
    return slug;
  };

  if (input.id) {
    const id = input.id;
    return commitCatalog(
      catalog.map((product) =>
        product.id === id
          ? { ...product, ...input, id, slug: product.name === input.name ? product.slug : uniqueSlug(id) }
          : product,
      ),
    );
  }
  return commitCatalog([...catalog, { ...input, id: uid("p"), slug: uniqueSlug() }]);
}

export function deleteProduct(id: string): Promise<boolean> {
  return commitCatalog(currentCatalog().filter((product) => product.id !== id));
}

export function setProductActive(id: string, active: boolean): Promise<boolean> {
  return commitCatalog(currentCatalog().map((product) => (product.id === id ? { ...product, active } : product)));
}

export function resetCatalog(): Promise<boolean> {
  return commitCatalog(null);
}

// settings
export async function saveSettings(next: Settings): Promise<boolean> {
  if (!firebaseConfigured) return settingsStore.set(next);
  return commitCatalog(currentCatalog(), next);
}

export function getCatalogSnapshot(): { products: Product[]; settings: Settings } {
  return { products: currentCatalog(), settings: { ...DEFAULT_SETTINGS, ...(settingsStore.get() ?? {}) } };
}

export function subscribeCatalogChanges(listener: () => void) {
  const unsubscribeCatalog = catalogStore.subscribe(listener);
  const unsubscribeSettings = settingsStore.subscribe(listener);
  return () => {
    unsubscribeCatalog();
    unsubscribeSettings();
  };
}

export function applyRemoteCatalog(products: Product[], settings: Partial<Settings>) {
  catalogStore.set(products);
  settingsStore.set({ ...DEFAULT_SETTINGS, ...settings });
}

export function getOrdersSnapshot(): Order[] {
  return ordersStore.get();
}

export function subscribeOrderChanges(listener: () => void) {
  return ordersStore.subscribe(listener);
}

export function applyRemoteOrders(orders: Order[]) {
  ordersStore.set(orders);
}

// backup / restore
export function exportBackup() {
  return JSON.stringify(
    {
      version: 1,
      exportedAt: new Date().toISOString(),
      products: currentCatalog(),
      orders: ordersStore.get(),
      settings: { ...DEFAULT_SETTINGS, ...(settingsStore.get() ?? {}) },
    },
    null,
    2,
  );
}

export function importBackup(json: string): string | null {
  try {
    const data = JSON.parse(json) as { products?: Product[]; orders?: Order[]; settings?: Settings };
    if (!data || typeof data !== "object") return "That file is not a valid backup.";
    const nextSettings = data.settings && typeof data.settings === "object" ? { ...DEFAULT_SETTINGS, ...data.settings } : undefined;
    if (Array.isArray(data.products)) {
      const valid = data.products.every((p) => p && typeof p.id === "string" && typeof p.name === "string" && typeof p.price === "number");
      if (!valid) return "The products in this backup are not in the expected format.";
      void commitCatalog(data.products, nextSettings);
    } else if (nextSettings) {
      void saveSettings(nextSettings);
    }
    if (Array.isArray(data.orders)) ordersStore.set(data.orders);
    return null;
  } catch {
    return "Could not read that file. Please choose a backup exported from this admin area.";
  }
}