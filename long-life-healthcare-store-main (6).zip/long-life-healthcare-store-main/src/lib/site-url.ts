/**
 * Works out the public address of the site from an incoming request, so the
 * sitemap is correct on any domain (preview, staging or your own) without
 * hard-coding it.
 */
export function getOrigin(request: Request): string {
  const url = new URL(request.url);
  const first = (value: string | null) => value?.split(",")[0]?.trim() || undefined;
  const proto = first(request.headers.get("x-forwarded-proto")) ?? url.protocol.replace(":", "");
  const host = first(request.headers.get("x-forwarded-host")) ?? first(request.headers.get("host")) ?? url.host;
  return `${proto}://${host}`;
}