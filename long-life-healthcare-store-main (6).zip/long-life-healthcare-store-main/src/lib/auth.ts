import { useSyncExternalStore } from "react";
import { onAuthStateChanged, signInWithEmailAndPassword, signOut as firebaseSignOut } from "firebase/auth";
import { doc, getDoc, setDoc } from "firebase/firestore";

import { getFirebaseAuth, getFirebaseDb, firebaseConfigured } from "@/lib/firebase";
import { hasAdminRole } from "@/lib/firebase-roles";

export type AuthState =
  | { status: "loading" }
  | { status: "unconfigured" }
  | { status: "signed-out" }
  | { status: "no-access"; email: string }
  | { status: "signed-in"; email: string; displayName: string };

let authState: AuthState = firebaseConfigured ? { status: "loading" } : { status: "unconfigured" };
const listeners = new Set<() => void>();
const subscribe = (listener: () => void) => {
  listeners.add(listener);
  return () => listeners.delete(listener);
};
const getSnapshot = () => authState;
const setAuthState = (next: AuthState) => {
  authState = next;
  listeners.forEach((listener) => listener());
};
const getServerSnapshot = (): AuthState => firebaseConfigured ? { status: "loading" } : { status: "unconfigured" };

export function initializeAdminAuth() {
  const auth = getFirebaseAuth();
  const db = getFirebaseDb();
  if (!auth || !db) {
    setAuthState({ status: "unconfigured" });
    return () => {};
  }

  let active = true;
  let revision = 0;
  const unsubscribe = onAuthStateChanged(auth, async (user) => {
    const currentRevision = ++revision;
    if (!user) {
      setAuthState({ status: "signed-out" });
      return;
    }
    setAuthState({ status: "loading" });
    try {
      const roleSnapshot = await getDoc(doc(db, "user_roles", user.uid));
      if (!active || currentRevision !== revision) return;
      if (!roleSnapshot.exists() || !hasAdminRole(roleSnapshot.data()["role"])) {
        setAuthState({ status: "no-access", email: user.email ?? "this account" });
        return;
      }
      const profileRef = doc(db, "profiles", user.uid);
      const profileSnapshot = await getDoc(profileRef);
      if (!active || currentRevision !== revision) return;
      const existing = profileSnapshot.exists() ? profileSnapshot.data() : {};
      const displayName = typeof existing["displayName"] === "string" && existing["displayName"].trim()
        ? existing["displayName"]
        : user.displayName || user.email?.split("@")[0] || "Staff";
      await setDoc(profileRef, {
        email: user.email ?? "",
        displayName,
        updatedAt: new Date().toISOString(),
      }, { merge: true });
      if (active && currentRevision === revision) {
        setAuthState({ status: "signed-in", email: user.email ?? "", displayName });
      }
    } catch {
      if (active && currentRevision === revision) {
        setAuthState({ status: "no-access", email: user.email ?? "this account" });
      }
    }
  }, () => {
    if (active) setAuthState({ status: "signed-out" });
  });

  return () => {
    active = false;
    unsubscribe();
  };
}

/** Returns an error message on failure, or null when signed in. */
export async function signIn(email: string, password: string): Promise<string | null> {
  const auth = getFirebaseAuth();
  if (!auth) return "Firebase is not configured yet. Add the Firebase web app settings, then refresh this page.";
  if (!email.trim() || !password) return "Enter your email and password.";
  try {
    await signInWithEmailAndPassword(auth, email.trim(), password);
    return null;
  } catch (error) {
    const code = error && typeof error === "object" && "code" in error ? error.code : "";
    if (code === "auth/invalid-credential" || code === "auth/wrong-password" || code === "auth/user-not-found") {
      return "Those details did not work. Check your email and password and try again.";
    }
    if (code === "auth/too-many-requests") return "Too many attempts. Please wait a moment and try again.";
    if (code === "auth/network-request-failed") return "Could not reach Firebase. Check your connection and try again.";
    return `Sign-in failed${code ? ` (${String(code)})` : ""}. Check the Firebase setup and try again.`;
  }
}

export async function signOut(): Promise<void> {
  const auth = getFirebaseAuth();
  if (auth) await firebaseSignOut(auth);
}

export function useAuth(): AuthState {
  return useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
}