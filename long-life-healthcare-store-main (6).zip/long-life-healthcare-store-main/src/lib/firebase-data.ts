import {
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  setDoc,
  type Unsubscribe,
} from "firebase/firestore";
import { getDownloadURL, ref, uploadBytes } from "firebase/storage";

import { getFirebaseAuth, getFirebaseDb, getFirebaseStorage } from "@/lib/firebase";
import { hasAdminRole } from "@/lib/firebase-roles";
import type { Order, Product, Settings } from "@/lib/store";

type CatalogDocument = { products?: Product[]; settings?: Partial<Settings> };

export function watchCatalog(onCatalog: (catalog: CatalogDocument | null) => void, onError: (error: Error) => void): Unsubscribe | null {
  const db = getFirebaseDb();
  if (!db) return null;
  return onSnapshot(doc(db, "catalog", "current"), (snapshot) => {
    // A cache-only "missing" answer is not trustworthy; wait for the server's answer.
    if (!snapshot.exists() && snapshot.metadata.fromCache) return;
    onCatalog(snapshot.exists() ? snapshot.data() as CatalogDocument : null);
  }, (error) => onError(error));
}

export async function saveCatalog(products: Product[], settings: Settings): Promise<void> {
  const db = getFirebaseDb();
  if (!db) return;
  await setDoc(doc(db, "catalog", "current"), { products, settings, updatedAt: new Date().toISOString() });
}

export function watchOrders(onOrders: (orders: Order[]) => void, onError: (error: Error) => void): Unsubscribe | null {
  const db = getFirebaseDb();
  if (!db) return null;
  return onSnapshot(collection(db, "orders"), (snapshot) => {
    const orders = snapshot.docs.map((item) => item.data() as Order);
    orders.sort((left, right) => right.createdAt.localeCompare(left.createdAt));
    onOrders(orders);
  }, (error) => onError(error));
}

export async function saveOrder(order: Order): Promise<void> {
  const db = getFirebaseDb();
  if (!db) return;
  await setDoc(doc(db, "orders", order.id), order);
}

export async function removeOrder(id: string): Promise<void> {
  const db = getFirebaseDb();
  if (!db) return;
  await deleteDoc(doc(db, "orders", id));
}

export async function uploadProductPhoto(file: File): Promise<string> {
  const storage = getFirebaseStorage();
  const auth = getFirebaseAuth();
  const user = auth?.currentUser;
  if (!storage || !auth || !user) throw new Error("Sign in with an authorized staff account before uploading photos.");
  const db = getFirebaseDb();
  if (!db) throw new Error("Firebase is not configured yet.");
  const roleSnapshot = await import("firebase/firestore").then(({ getDoc }) => getDoc(doc(db, "user_roles", user.uid)));
  if (!roleSnapshot.exists() || !hasAdminRole(roleSnapshot.data()["role"])) {
    throw new Error("Only authorized staff can upload product photos.");
  }
  const safeName = file.name.toLowerCase().replace(/[^a-z0-9.-]+/g, "-").slice(-100) || "product-image";
  const object = ref(storage, `products/${user.uid}/${crypto.randomUUID()}-${safeName}`);
  await uploadBytes(object, file, { contentType: file.type });
  return getDownloadURL(object);
}