export type DrugClassification = {
  name: string;
  examples: string[];
};

/** Classification names and example medicines transcribed from the supplied PDF. */
export const DRUG_CLASSIFICATIONS: DrugClassification[] = [
  { name: "Analgesics (painkillers)", examples: ["Acycor plus", "ATP tablet", "Long Life Pentazocine injection", "Jubilee Pentazocine injection", "Pentev injection"] },
  { name: "Antibiotics", examples: ["Cimoxil capsules 500mg", "Jubiclox capsules 250mg", "Jubiclox injection", "Elium injection", "Tinam 1g injection (Ceftriaxone 1 g)", "Jubi-Ciprofloxacin tablet", "Long Life Ciprofloxacin tablet"] },
  { name: "Antimalarials", examples: ["SMT-Forte", "Jubilee Artesunate injection 60mg", "Jubilee Artesunate injection 120mg", "Paraline injection 80mg/ml"] },
  { name: "Antihypertensives", examples: ["Amlodipine 5 & 10mg", "Jubilee Lisinopril 5 & 10mg", "Jubretic"] },
  { name: "Antidiabetics", examples: ["Metformin", "Insulin", "Glibenclamide"] },
  { name: "Antifungals", examples: ["Fluconazole", "Clotrimazole", "Nystatin", "Grenin tablet 500mg"] },
  { name: "Antivirals", examples: ["Acyclovir", "Tenofovir", "Oseltamivir"] },
  { name: "Anthelmintics", examples: ["Albendazole", "Mebendazole", "Praziquantel"] },
  { name: "Antacids", examples: ["Magnesium hydroxide", "Aluminium hydroxide"] },
  { name: "Antiulcer drugs", examples: ["Omeprazole", "Pantoprazole", "Famotidine"] },
  { name: "Antihistamines", examples: ["Cetirizine", "Loratadine", "Chlorpheniramine"] },
  { name: "Antiemetics", examples: ["Ondansetron", "Metoclopramide"] },
  { name: "Antidiarrhoeals", examples: ["Loperamide", "Racecadotril"] },
  { name: "Laxatives", examples: ["Lactulose", "Bisacodyl"] },
  { name: "Anticoagulants", examples: ["Heparin", "Warfarin", "Apixaban"] },
  { name: "Anticonvulsants", examples: ["Sodium valproate", "Carbamazepine"] },
  { name: "Antidepressants", examples: ["Fluoxetine", "Amitriptyline"] },
  { name: "Antipsychotics", examples: ["Haloperidol", "Risperidone"] },
  { name: "Bronchodilators", examples: ["Salbutamol", "Ipratropium"] },
  { name: "Corticosteroids", examples: ["Prednisolone", "Dexamethasone"] },
  { name: "Diuretics", examples: ["Furosemide", "Hydrochlorothiazide", "Jubretic tablet"] },
  { name: "Muscle relaxants", examples: ["Baclofen", "Diazepam"] },
  { name: "Hormones", examples: ["Levothyroxine", "Hydrocortisone"] },
  { name: "Vaccines", examples: ["BCG", "Hepatitis B vaccine"] },
];

export const DRUG_CLASSIFICATION_NAMES = DRUG_CLASSIFICATIONS.map(({ name }) => name);