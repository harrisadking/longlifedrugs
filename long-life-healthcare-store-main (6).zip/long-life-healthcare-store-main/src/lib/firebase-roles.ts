export function hasAdminRole(role: unknown): boolean {
  return role === "admin";
}