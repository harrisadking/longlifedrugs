/**
 * Data access used by routes and components.
 *
 * Thin layer over the browser store in `./store`, so pages depend on these
 * functions rather than on the storage details.
 */
import {
  DEFAULT_PRODUCTS,
  DEFAULT_SETTINGS,
  cartTotal,
  orderSummary,
  recordOrder,
  type CartLine,
  type Order,
  type Product,
  type Settings,
} from "./store";

export type Catalog = { products: Product[]; settings: Settings };

/** Baseline catalog for the root route loader (safe on the server and in the browser). */
export async function loadCatalog(): Promise<Catalog> {
  return { products: DEFAULT_PRODUCTS, settings: DEFAULT_SETTINGS };
}

export type OrderDetails = { name?: string; phone?: string; address?: string; note?: string };

/** Records a website order before the shopper is sent to WhatsApp. */
export async function placeOrder(lines: CartLine[], details: OrderDetails = {}): Promise<Order | null> {
  if (!lines.length) return null;
  const note = details.note?.trim();
  return recordOrder({
    customer: details.name?.trim() ?? "",
    phone: details.phone?.trim() ?? "",
    address: details.address?.trim() ?? "",
    summary: note ? `${orderSummary(lines)}\nNote: ${note}` : orderSummary(lines),
    total: cartTotal(lines),
    source: "website",
  });
}
