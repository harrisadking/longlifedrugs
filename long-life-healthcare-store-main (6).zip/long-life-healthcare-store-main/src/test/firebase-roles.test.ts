import { describe, expect, it } from "vitest";

import { hasAdminRole } from "@/lib/firebase-roles";

describe("Firebase staff roles", () => {
  it("grants admin access only to the explicit admin role", () => {
    expect(hasAdminRole("admin")).toBe(true);
    expect(hasAdminRole("staff")).toBe(false);
    expect(hasAdminRole(undefined)).toBe(false);
  });
});