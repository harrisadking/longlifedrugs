import { describe, expect, it } from "vitest";

import { DRUG_CLASSIFICATIONS, DRUG_CLASSIFICATION_NAMES } from "@/lib/drug-classifications";

describe("PDF drug classifications", () => {
  it("contains all 24 unique classifications, counting the repeated Antiemetics entry once", () => {
    expect(DRUG_CLASSIFICATIONS).toHaveLength(24);
    expect(new Set(DRUG_CLASSIFICATION_NAMES).size).toBe(24);
  });

  it("preserves the antibiotic examples listed in the PDF", () => {
    const antibiotics = DRUG_CLASSIFICATIONS.find(({ name }) => name === "Antibiotics");

    expect(antibiotics?.examples).toContain("Cimoxil capsules 500mg");
    expect(antibiotics?.examples).toContain("Long Life Ciprofloxacin tablet");
  });
});